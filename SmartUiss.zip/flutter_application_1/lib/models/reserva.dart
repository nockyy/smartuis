// lib/models/reserva.dart
import 'package:flutter/material.dart';

class Reserva {
  int? id;
  int userId; 
  String tipo;
  DateTime fecha;
  int horaHour;
  int horaMinute;
  bool confirmed;

  Reserva({
    this.id,
    required this.userId,
    required this.tipo,
    required this.fecha,
    required TimeOfDay hora,
    this.confirmed = false, 
  })  : horaHour = hora.hour,
        horaMinute = hora.minute;


  TimeOfDay get hora => TimeOfDay(hour: horaHour, minute: horaMinute);

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'tipo': tipo,
      'fecha': fecha.toIso8601String(),
      'horaHour': horaHour,
      'horaMinute': horaMinute,
      'confirmed': confirmed ? 1 : 0, 
    };
  }


  factory Reserva.fromMap(Map<String, dynamic> map) {
    return Reserva(
      id: map['id'],
      userId: map['userId'],
      tipo: map['tipo'],
      fecha: DateTime.parse(map['fecha']), 
      hora: TimeOfDay(hour: map['horaHour'], minute: map['horaMinute']),
      confirmed: map['confirmed'] == 1,
    );
  }
}