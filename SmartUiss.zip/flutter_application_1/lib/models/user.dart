// lib/models/user.dart
import 'package:flutter/material.dart'; 

class User {
  int? id; 
  String email;
  String password; 
  String name;
  String lastName;
  String studentCode;
  String? profileFrame;

  User({
    this.id,
    required this.email,
    required this.password,
    required this.name,
    required this.lastName,
    required this.studentCode,
    this.profileFrame,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'email': email,
      'password': password,
      'name': name,
      'lastName': lastName,
      'studentCode': studentCode,
      'profileFrame': profileFrame,
    };
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['id'],
      email: map['email'],
      password: map['password'],
      name: map['name'],
      lastName: map['lastName'],
      studentCode: map['studentCode'],
      profileFrame: map['profileFrame'],
    );
  }
}