// lib/database_helper.dart
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

import 'package:flutter_application_1/models/user.dart'; 
import 'package:flutter_application_1/models/reserva.dart'; 

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  static Database? _database;

  factory DatabaseHelper() {
    return _instance;
  }

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, 'smartuis.db');
    print('Ruta de la base de datos: $path'); // Útil para depuración con DBeaver

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future _onCreate(Database db, int version) async {
    // Crear tabla de usuarios
    await db.execute('''
      CREATE TABLE users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE,
        password TEXT,
        name TEXT,
        lastName TEXT,
        studentCode TEXT UNIQUE,
        profileFrame TEXT
      )
    ''');

    // Crear tabla de reservas
    await db.execute('''
      CREATE TABLE reservas(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId INTEGER,
        tipo TEXT,
        fecha TEXT,
        horaHour INTEGER,
        horaMinute INTEGER,
        confirmed INTEGER,
        FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
      )
    ''');
  }

  // --- Métodos CRUD para User ---

  Future<int> insertUser(User user) async {
    Database db = await database;
    return await db.insert('users', user.toMap());
  }

  Future<User?> getUser(String email, String password) async {
    Database db = await database;
    List<Map<String, dynamic>> maps = await db.query(
      'users',
      where: 'email = ? AND password = ?',
      whereArgs: [email, password],
    );
    if (maps.isNotEmpty) {
      return User.fromMap(maps.first);
    }
    return null;
  }

  Future<User?> getUserByStudentCode(String studentCode) async {
    Database db = await database;
    List<Map<String, dynamic>> maps = await db.query(
      'users',
      where: 'studentCode = ?',
      whereArgs: [studentCode],
    );
    if (maps.isNotEmpty) {
      return User.fromMap(maps.first);
    }
    return null;
  }

  Future<int> updateUser(User user) async {
    Database db = await database;
    return await db.update(
      'users',
      user.toMap(),
      where: 'id = ?',
      whereArgs: [user.id],
    );
  }

  Future<int> deleteUser(int id) async {
    Database db = await database;
    return await db.delete(
      'users',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // --- Métodos CRUD para Reserva ---

  Future<int> insertReserva(Reserva reserva) async {
    Database db = await database;
    return await db.insert('reservas', reserva.toMap());
  }

  Future<Reserva?> getActiveReservaForUser(int userId) async {
    Database db = await database;
    List<Map<String, dynamic>> maps = await db.query(
      'reservas',
      where: 'userId = ? AND confirmed = 0', // Buscar reserva no confirmada
      whereArgs: [userId],
      orderBy: 'fecha DESC, horaHour DESC, horaMinute DESC', // Solo la más reciente si hay varias
      limit: 1,
    );
    if (maps.isNotEmpty) {
      return Reserva.fromMap(maps.first);
    }
    return null;
  }

  Future<List<Reserva>> getConfirmedReservasForUser(int userId) async {
    Database db = await database;
    List<Map<String, dynamic>> maps = await db.query(
      'reservas',
      where: 'userId = ? AND confirmed = 1', // Buscar reservas confirmadas
      whereArgs: [userId],
      orderBy: 'fecha DESC, horaHour DESC, horaMinute DESC', // Ordenar por fecha y hora
    );
    return List.generate(maps.length, (i) {
      return Reserva.fromMap(maps[i]);
    });
  }

  Future<int> updateReserva(Reserva reserva) async {
    Database db = await database;
    return await db.update(
      'reservas',
      reserva.toMap(),
      where: 'id = ?',
      whereArgs: [reserva.id],
    );
  }

  Future<int> deleteReserva(int id) async {
    Database db = await database;
    return await db.delete(
      'reservas',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}